#include "middle.h"
void itc_num_print(int a)
{
    cout<<a;
}
